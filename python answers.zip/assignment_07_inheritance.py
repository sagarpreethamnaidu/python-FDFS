# Assignment-7: Inheritance & Polymorphism in Python

# Q1 & Q2. Create Class Hierarchy with Methods
print("=" * 40)
print("Q1 & Q2. Class Hierarchy and Methods")
print("=" * 40)

class A:
    def method_a1(self):
        print("Method A1 - specific to class A")

    def method_a2(self):
        print("Method A2 - specific to class A")

    def common_method(self):
        print("Common method in class A")


class B(A):
    def method_b1(self):
        print("Method B1 - specific to class B")

    def method_b2(self):
        print("Method B2 - specific to class B")

    def common_method(self):  # overriding A's method
        print("Common method overridden in class B")


class C(B):
    def method_c1(self):
        print("Method C1 - specific to class C")

    def method_c2(self):
        print("Method C2 - specific to class C")

    def common_method(self):  # overriding B's method
        print("Common method overridden in class C")


# Q3. Object Creation and Method Calls
print("\n" + "=" * 40)
print("Q3. Object Creation and Method Calls")
print("=" * 40)

obj_a = A()
obj_b = B()
obj_c = C()

print("\n--- Class A Object ---")
obj_a.method_a1()
obj_a.method_a2()
obj_a.common_method()

print("\n--- Class B Object ---")
obj_b.method_b1()
obj_b.method_b2()
obj_b.common_method()
obj_b.method_a1()  # inherited from A

print("\n--- Class C Object ---")
obj_c.method_c1()
obj_c.method_c2()
obj_c.common_method()
obj_c.method_b1()  # inherited from B
obj_c.method_a1()  # inherited from A

# Q4. Polymorphism Demo
print("\n" + "=" * 40)
print("Q4. Polymorphism (same method, different behaviour)")
print("=" * 40)
for obj in [obj_a, obj_b, obj_c]:
    obj.common_method()

# Q5. isinstance() Check
print("\n" + "=" * 40)
print("Q5. isinstance() Check")
print("=" * 40)
print(f"obj_c is instance of C: {isinstance(obj_c, C)}")
print(f"obj_c is instance of B: {isinstance(obj_c, B)}")
print(f"obj_c is instance of A: {isinstance(obj_c, A)}")
