# Assignment-15: Dictionaries in Python

# Q1. Create a Dictionary
print("=" * 40)
print("Q1. Create Student Dictionary")
print("=" * 40)
students = {
    101: "Sagar",
    102: "Ravi",
    103: "Priya",
    104: "Anjali",
    105: "Kiran"
}
print("Students:", students)

# Q1.1 Add New Entries
print("\n--- Q1.1 Add New Entries ---")
students[106] = "Deepak"
students[107] = "Sneha"
print("After adding:", students)

# Q1.2 Update Existing Values
print("\n--- Q1.2 Update Existing Values ---")
students[102] = "Ravi Kumar"
print("After updating 102:", students)

# Q1.3 Access Values
print("\n--- Q1.3 Access Values ---")
print(f"Student with ID 103: {students[103]}")
print("All student names:", list(students.values()))

# Q1.4 Iterate Through Dictionary
print("\n--- Q1.4 Iterate Dictionary ---")
for key, value in students.items():
    print(f"  ID: {key}, Name: {value}")

# Q1.5 Print Only Keys
print("\n--- Q1.5 Print Only Keys (IDs) ---")
print("Student IDs:", list(students.keys()))

# Q1.6 Print Only Values
print("\n--- Q1.6 Print Only Values (Names) ---")
print("Student Names:", list(students.values()))

# Q1.7 Nested Dictionary
print("\n--- Q1.7 Nested Dictionary ---")
nested_students = {
    101: {"name": "Sagar", "age": 21},
    102: {"name": "Ravi", "age": 22},
    103: {"name": "Priya", "age": 20}
}
print("Nested students:", nested_students)

# Q1.8 Access Nested Values
print("\n--- Q1.8 Access Nested Values ---")
print(f"Name of student 101: {nested_students[101]['name']}")
print(f"Age of student 102: {nested_students[102]['age']}")

# Q1.9 Delete Elements
print("\n--- Q1.9 Delete Elements ---")
del students[107]
print(f"After del 107: {students}")

last = students.popitem()
print(f"popitem() removed: {last}")
print(f"After popitem: {students}")

removed = students.pop(101)
print(f"pop(101) removed: {removed}")
print(f"After pop(101): {students}")

# Q2. Check Key Existence
print("\n" + "=" * 40)
print("Q2. Check Key Existence")
print("=" * 40)
print(f"102 in students: {102 in students}")
print(f"999 in students: {999 in students}")

# Q3. Count Entries
print("\n" + "=" * 40)
print("Q3. Count Entries")
print("=" * 40)
print(f"Total students: {len(students)}")

# Q4. Merge Two Dictionaries
print("\n" + "=" * 40)
print("Q4. Merge Two Dictionaries")
print("=" * 40)
dict1 = {201: "Alpha", 202: "Beta"}
dict2 = {203: "Gamma", 204: "Delta"}
merged = {**dict1, **dict2}
print("Dict1:", dict1)
print("Dict2:", dict2)
print("Merged:", merged)

# Q5. Dictionary Comprehension
print("\n" + "=" * 40)
print("Q5. Dictionary Comprehension (squares)")
print("=" * 40)
squares = {n: n**2 for n in range(1, 11)}
print("Squares:", squares)

# Q6. Reverse Dictionary (swap keys and values)
print("\n" + "=" * 40)
print("Q6. Reverse Dictionary")
print("=" * 40)
original = {101: "Sagar", 102: "Ravi", 103: "Priya"}
reversed_dict = {v: k for k, v in original.items()}
print("Original:", original)
print("Reversed:", reversed_dict)
