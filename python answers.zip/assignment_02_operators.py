# Assignment-2: Operators in Python

# Q1. Basic Arithmetic Operations
print("=" * 40)
print("Q1. Basic Arithmetic Operations")
print("=" * 40)
def arithmetic(a, b):
    print(f"Addition:       {a} + {b} = {a + b}")
    print(f"Subtraction:    {a} - {b} = {a - b}")
    print(f"Multiplication: {a} * {b} = {a * b}")
    print(f"Division:       {a} / {b} = {a / b}")

arithmetic(10, 3)

# Q2. Simulating Increment and Decrement
print("\n" + "=" * 40)
print("Q2. Increment and Decrement")
print("=" * 40)
def increment_decrement(n):
    print(f"Original value: {n}")
    n += 1
    print(f"After increment (+=1): {n}")
    n -= 1
    print(f"After decrement (-=1): {n}")

increment_decrement(5)

# Q3. Check if Two Numbers are Equal
print("\n" + "=" * 40)
print("Q3. Check if Two Numbers are Equal")
print("=" * 40)
a, b = 10, 10
if a == b:
    print(f"{a} and {b} are EQUAL")
else:
    print(f"{a} and {b} are NOT EQUAL")

a, b = 10, 20
if a == b:
    print(f"{a} and {b} are EQUAL")
else:
    print(f"{a} and {b} are NOT EQUAL")

# Q4. Relational Operators
print("\n" + "=" * 40)
print("Q4. Relational Operators")
print("=" * 40)
x, y = 10, 20
print(f"x = {x}, y = {y}")
print(f"x < y  : {x < y}")
print(f"x <= y : {x <= y}")
print(f"x > y  : {x > y}")
print(f"x >= y : {x >= y}")
