# Assignment-10: Packages & Modules in Python
# All code is in one file for demonstration; in practice these would be separate files.

# ---- Simulated: mypackage/class_one.py ----
class ClassOne:
    def __init__(self, value="Default Value"):
        self.value = value

    def display(self):
        print(f"ClassOne - Value: {self.value}")

    def greet(self):
        print("Hello from ClassOne!")


# ---- Simulated: mypackage/class_two.py ----
class ClassTwo:
    def __init__(self, number=0):
        self.number = number

    def show(self):
        print(f"ClassTwo - Number: {self.number}")

    def square(self):
        print(f"Square of {self.number} = {self.number ** 2}")


# ---- Simulated: mypackage/__init__.py ----
# from mypackage.class_one import ClassOne
# from mypackage.class_two import ClassTwo

# ---- Simulated: main.py ----
print("=" * 40)
print("Q1 & Q2. Classes in Package")
print("=" * 40)
print("ClassOne and ClassTwo defined (simulating mypackage/)")

print("\n" + "=" * 40)
print("Q3. Import and Use Classes")
print("=" * 40)

# Using ClassOne
print("\n--- ClassOne ---")
obj1 = ClassOne("Python Package Demo")
obj1.display()
obj1.greet()

obj1_default = ClassOne()
obj1_default.display()

# Using ClassTwo
print("\n--- ClassTwo ---")
obj2 = ClassTwo(9)
obj2.show()
obj2.square()

obj2_default = ClassTwo()
obj2_default.show()

print("\n" + "=" * 40)
print("Package structure (how it looks on disk)")
print("=" * 40)
print("""
mypackage/
    __init__.py       -> from mypackage.class_one import ClassOne
                         from mypackage.class_two import ClassTwo
    class_one.py      -> contains ClassOne
    class_two.py      -> contains ClassTwo
main.py               -> imports and uses both classes
""")
