# Assignment-8: Encapsulation & Data Control in Python

# Q1. Create a Simple Class with Setters and Getters
print("=" * 40)
print("Q1. Simple Class with Getter/Setter")
print("=" * 40)
class Student:
    def __init__(self):
        self.name = ""
        self.age = 0

    def set_name(self, name):
        self.name = name

    def get_name(self):
        return self.name

    def set_age(self, age):
        self.age = age

    def get_age(self):
        return self.age

s = Student()
s.set_name("Sagar")
s.set_age(21)
print(f"Name: {s.get_name()}, Age: {s.get_age()}")

# Q2. Validation Using Methods
print("\n" + "=" * 40)
print("Q2. Validation Using Methods")
print("=" * 40)
class StudentV2:
    def __init__(self):
        self.name = ""
        self.age = 0

    def set_age(self, age):
        if age > 0:
            self.age = age
        else:
            print("Error: Age must be greater than 0")

    def get_age(self):
        return self.age

s2 = StudentV2()
s2.set_age(21)
print(f"Valid age set: {s2.get_age()}")
s2.set_age(-5)

# Q3. Property Decorator
print("\n" + "=" * 40)
print("Q3. Property Decorator")
print("=" * 40)
class StudentV3:
    def __init__(self, name, age):
        self._name = name
        self._age = age

    @property
    def age(self):
        return self._age

    @age.setter
    def age(self, value):
        if value > 0:
            self._age = value
        else:
            print("Error: Age must be positive")

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        self._name = value

s3 = StudentV3("Ravi", 22)
print(f"Name: {s3.name}, Age: {s3.age}")
s3.age = 25
print(f"Updated Age: {s3.age}")
s3.age = -1  # triggers validation

# Q4. Read-Only Property
print("\n" + "=" * 40)
print("Q4. Read-Only Property")
print("=" * 40)
class Employee:
    def __init__(self, emp_id, name):
        self.__id = emp_id
        self.name = name

    @property
    def id(self):
        return self.__id

emp = Employee(101, "Sagar")
print(f"Employee ID: {emp.id}, Name: {emp.name}")
try:
    emp.id = 999  # should fail
except AttributeError as e:
    print(f"Cannot modify read-only property: {e}")

# Q5. Bank Account System
print("\n" + "=" * 40)
print("Q5. Bank Account System")
print("=" * 40)
class BankAccount:
    def __init__(self, owner, balance=0):
        self.__owner = owner
        self.__balance = balance

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print(f"Deposited {amount}. Balance: {self.__balance}")
        else:
            print("Invalid deposit amount")

    def withdraw(self, amount):
        if amount > self.__balance:
            print("Insufficient balance!")
        elif amount <= 0:
            print("Invalid withdrawal amount")
        else:
            self.__balance -= amount
            print(f"Withdrawn {amount}. Balance: {self.__balance}")

    def get_balance(self):
        return self.__balance

    def __str__(self):
        return f"Account Owner: {self.__owner}, Balance: {self.__balance}"

acc = BankAccount("Sagar", 1000)
print(acc)
acc.deposit(500)
acc.withdraw(200)
acc.withdraw(2000)
print(f"Final Balance: {acc.get_balance()}")
