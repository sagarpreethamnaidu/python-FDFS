# Assignment-12: Constructors in Python

# Q1. Default and Parameterized Constructors
print("=" * 40)
print("Q1. Default and Parameterized Constructors")
print("=" * 40)

class Person:
    def __init__(self, name="Unknown", age=0):
        self.name = name
        self.age = age
        print(f"Object created -> Name: {self.name}, Age: {self.age}")

# Default constructor (no args)
p1 = Person()

# One-argument constructor
p2 = Person("Sagar")

# Two-argument constructor
p3 = Person("Ravi", 25)

# Q2. Calling Parent Constructor with super()
print("\n" + "=" * 40)
print("Q2. Calling Parent Constructor")
print("=" * 40)

class Animal:
    def __init__(self, name):
        self.name = name
        print(f"Animal constructor called - Name: {self.name}")

class Dog(Animal):
    def __init__(self, name, breed):
        super().__init__(name)  # call parent constructor
        self.breed = breed
        print(f"Dog constructor called - Breed: {self.breed}")

    def info(self):
        print(f"Dog: {self.name}, Breed: {self.breed}")

d = Dog("Bruno", "Labrador")
d.info()

# Q3. Simulating Access Levels
print("\n" + "=" * 40)
print("Q3. Simulating Access Levels")
print("=" * 40)

class AccessDemo:
    def __init__(self):
        self.public_var = "I am Public"          # public
        self._protected_var = "I am Protected"    # protected (convention)
        self.__private_var = "I am Private"       # private (name mangling)

obj = AccessDemo()

# Public - accessible anywhere
print(f"Public: {obj.public_var}")

# Protected - accessible but by convention should not be used outside
print(f"Protected: {obj._protected_var}")

# Private - name mangled, direct access fails
try:
    print(obj.__private_var)
except AttributeError as e:
    print(f"Private access error: {e}")

# Access private via mangled name
print(f"Private (via mangled name): {obj._AccessDemo__private_var}")
