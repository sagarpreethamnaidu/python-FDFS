# Assignment-9: Abstract Classes in Python

from abc import ABC, abstractmethod

# Q1. Abstract and Non-Abstract Methods
print("=" * 40)
print("Q1. Abstract Class Definition")
print("=" * 40)

class Animal(ABC):
    @abstractmethod
    def make_sound(self):
        pass  # no implementation

    def breathe(self):
        print("All animals breathe oxygen")

print("Abstract class Animal created with abstract method make_sound()")
print("and non-abstract method breathe()")

# Q2. Create a Child Class
print("\n" + "=" * 40)
print("Q2. Child Class Implementing Abstract Method")
print("=" * 40)

class Dog(Animal):
    def make_sound(self):
        print("Dog says: Woof!")

class Cat(Animal):
    def make_sound(self):
        print("Cat says: Meow!")

print("Dog and Cat classes created, implementing make_sound()")

# Q3. Access Non-Abstract Method via Child Object
print("\n" + "=" * 40)
print("Q3. Calling Non-Abstract (Inherited) Method")
print("=" * 40)
dog = Dog()
dog.breathe()  # inherited from Animal

# Q4. Call Abstract Method Implementation
print("\n" + "=" * 40)
print("Q4. Calling Implemented Abstract Method")
print("=" * 40)
dog.make_sound()

cat = Cat()
cat.make_sound()

# Q5. Attempt to Instantiate Abstract Class
print("\n" + "=" * 40)
print("Q5. Instantiating Abstract Class (Should Fail)")
print("=" * 40)
try:
    a = Animal()
except TypeError as e:
    print(f"Error: {e}")
    print("Cannot create object of abstract class directly!")

# Q6. Multiple Abstract Methods
print("\n" + "=" * 40)
print("Q6. Multiple Abstract Methods")
print("=" * 40)

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

    @abstractmethod
    def perimeter(self):
        pass

    def describe(self):
        print(f"This is a shape with area={self.area():.2f} and perimeter={self.perimeter():.2f}")

class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def area(self):
        return self.width * self.height

    def perimeter(self):
        return 2 * (self.width + self.height)

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14159 * self.radius ** 2

    def perimeter(self):
        return 2 * 3.14159 * self.radius

rect = Rectangle(5, 3)
rect.describe()

circle = Circle(7)
circle.describe()
