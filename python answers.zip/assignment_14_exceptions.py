# Assignment-14: Exception Handling in Python

import logging

# Q1. Generate an Exception (no handling)
print("=" * 40)
print("Q1. Generate an Exception")
print("=" * 40)
print("Code: result = 10 / 0")
print("This causes ZeroDivisionError (we skip running it to continue demo)")

# Q2. Handle the Exception
print("\n" + "=" * 40)
print("Q2. Handle the Exception")
print("=" * 40)
try:
    result = 10 / 0
except ZeroDivisionError:
    print("Caught ZeroDivisionError: Cannot divide by zero!")

# Q3. Multiple Except Blocks
print("\n" + "=" * 40)
print("Q3. Multiple Except Blocks")
print("=" * 40)
def divide(a, b):
    try:
        result = a / b
        print(f"Result: {result}")
    except ZeroDivisionError:
        print("Error: Cannot divide by zero!")
    except TypeError:
        print("Error: Invalid input type!")

divide(10, 2)
divide(10, 0)
divide(10, "a")

# Q4. Raise an Exception Manually
print("\n" + "=" * 40)
print("Q4. Raise an Exception Manually")
print("=" * 40)
def check_age(age):
    if age < 18:
        raise ValueError(f"Age {age} is not allowed. Must be 18 or above.")
    print(f"Age {age} is valid. Welcome!")

try:
    check_age(21)
    check_age(15)
except ValueError as e:
    print(f"Caught: {e}")

# Q5. Function That Always Raises Exception
print("\n" + "=" * 40)
print("Q5. Function That Raises Exception")
print("=" * 40)
def always_fails():
    raise RuntimeError("This function always fails!")

try:
    always_fails()
except RuntimeError as e:
    print(f"Handled RuntimeError: {e}")

# Q6. Custom Exception
print("\n" + "=" * 40)
print("Q6. Custom Exception - InsufficientBalanceError")
print("=" * 40)
class InsufficientBalanceError(Exception):
    def __init__(self, amount, balance):
        super().__init__(f"Cannot withdraw {amount}. Balance is only {balance}.")

def withdraw(balance, amount):
    if amount > balance:
        raise InsufficientBalanceError(amount, balance)
    balance -= amount
    print(f"Withdrawal successful. New balance: {balance}")
    return balance

try:
    withdraw(500, 200)
    withdraw(500, 700)
except InsufficientBalanceError as e:
    print(f"Custom Exception: {e}")

# Q7. Using finally
print("\n" + "=" * 40)
print("Q7. Using finally")
print("=" * 40)
try:
    f = open("/tmp/testfile.txt", "w")
    f.write("Test data")
    print("File written successfully")
except IOError as e:
    print(f"File error: {e}")
finally:
    f.close()
    print("File closed in finally block (always runs)")

# Q8. File Not Found
print("\n" + "=" * 40)
print("Q8. FileNotFoundError")
print("=" * 40)
try:
    with open("/tmp/nonexistent_file.txt", "r") as f:
        content = f.read()
except FileNotFoundError as e:
    print(f"Caught FileNotFoundError: {e}")

# Q9. TypeError
print("\n" + "=" * 40)
print("Q9. TypeError")
print("=" * 40)
try:
    result = "hello" + 5
except TypeError as e:
    print(f"Caught TypeError: {e}")

# Q10. AttributeError
print("\n" + "=" * 40)
print("Q10. AttributeError")
print("=" * 40)
try:
    x = 42
    x.upper()  # int has no upper()
except AttributeError as e:
    print(f"Caught AttributeError: {e}")

# Q11. IndexError
print("\n" + "=" * 40)
print("Q11. IndexError")
print("=" * 40)
try:
    lst = [1, 2, 3]
    print(lst[10])
except IndexError as e:
    print(f"Caught IndexError: {e}")

# Q12. else Block
print("\n" + "=" * 40)
print("Q12. else Block in try-except")
print("=" * 40)
try:
    result = 10 / 2
except ZeroDivisionError:
    print("Division by zero error")
else:
    print(f"No exception occurred. Result = {result}")

# Q13. Logging Errors
print("\n" + "=" * 40)
print("Q13. Logging Errors")
print("=" * 40)
logging.basicConfig(level=logging.ERROR, format="%(levelname)s: %(message)s")
try:
    x = int("abc")
except ValueError as e:
    logging.error(f"ValueError caught: {e}")
    print("Error was logged using logging module")

# Q14. Input Validation System
print("\n" + "=" * 40)
print("Q14. Input Validation System (simulated)")
print("=" * 40)
inputs = ["abc", "0", "25"]  # simulated user inputs

for user_input in inputs:
    try:
        val = int(user_input)
        if val == 0:
            raise ZeroDivisionError
        result = 100 / val
        print(f"Valid input: {val}, Result = 100/{val} = {result:.2f}")
        break
    except ValueError:
        print(f"Invalid input '{user_input}': Please enter a number")
    except ZeroDivisionError:
        print(f"Input '{user_input}': Cannot be zero, try again")
