# Assignment-1: Python Basics & Variables

# Q1. Print Your Name
print("=" * 40)
print("Q1. Print Your Name")
print("=" * 40)
print("Sagar Preetham Naidu")

# Q2. Comments in Python
print("\n" + "=" * 40)
print("Q2. Comments in Python")
print("=" * 40)
# This is a single-line comment

"""
This is a multi-line comment.
It can span across multiple lines.
It is written using triple quotes.
"""

print("Comments are used to explain code and make it more readable.")
print("Single-line comments start with #")
print("Multi-line comments use triple quotes.")

# Q3. Working with Basic Data Types
print("\n" + "=" * 40)
print("Q3. Basic Data Types")
print("=" * 40)
age = 21
print(f"Integer: {age}, Type: {type(age)}")

height = 5.9
print(f"Float: {height}, Type: {type(height)}")

is_student = True
print(f"Boolean: {is_student}, Type: {type(is_student)}")

name = "Sagar"
print(f"String: {name}, Type: {type(name)}")

char = "A"
print(f"Single-char String: {char}, Type: {type(char)}")

# Q4. Local vs Global Variables
print("\n" + "=" * 40)
print("Q4. Local vs Global Variables")
print("=" * 40)
x = 100  # global variable

def show_variables():
    x = 50  # local variable
    print(f"Inside function - Local x: {x}")
    print(f"Inside function - Global x: {globals()['x']}")

show_variables()

def modify_global():
    global x
    x = 200
    print(f"Modified global x inside function: {x}")

modify_global()
print(f"Global x after modification: {x}")

# Q5. Type Checking & Dynamic Typing
print("\n" + "=" * 40)
print("Q5. Type Checking & Dynamic Typing")
print("=" * 40)
var = 10
print(f"Value: {var}, Type: {type(var)}")

var = 10.5
print(f"Value: {var}, Type: {type(var)}")

var = "Hello"
print(f"Value: {var}, Type: {type(var)}")

var = True
print(f"Value: {var}, Type: {type(var)}")
