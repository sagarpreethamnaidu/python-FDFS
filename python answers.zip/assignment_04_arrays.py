# Assignment-4: Lists (Arrays) in Python

nums = [4, 7, 2, 9, 1, 5, 7, 3, 2, 8, 12, 23]

# Q1. Sum of Elements
print("=" * 40)
print("Q1. Sum of Elements")
print("=" * 40)
def sum_elements(lst):
    total = 0
    for n in lst:
        total += n
    return total

print(f"List: {nums}")
print(f"Sum: {sum_elements(nums)}")

# Q2. Average of Elements
print("\n" + "=" * 40)
print("Q2. Average of Elements")
print("=" * 40)
def average(lst):
    return sum_elements(lst) / len(lst)

print(f"Average: {average(nums):.2f}")

# Q3. Find Index of an Element
print("\n" + "=" * 40)
print("Q3. Find Index of Element")
print("=" * 40)
def find_index(lst, val):
    if val in lst:
        print(f"Element {val} found at index: {lst.index(val)}")
    else:
        print(f"Element {val} not found in list")

find_index(nums, 9)
find_index(nums, 99)

# Q4. Check Element Presence
print("\n" + "=" * 40)
print("Q4. Check Element Presence")
print("=" * 40)
def check_presence(lst, val):
    return val in lst

print(f"5 in list: {check_presence(nums, 5)}")
print(f"99 in list: {check_presence(nums, 99)}")

# Q5. Remove an Element
print("\n" + "=" * 40)
print("Q5. Remove an Element")
print("=" * 40)
def remove_element(lst, val):
    copy = lst[:]
    if val in copy:
        copy.remove(val)
        print(f"After removing {val}: {copy}")
    else:
        print(f"{val} not found in list")

remove_element(nums, 7)

# Q6. Copy a List
print("\n" + "=" * 40)
print("Q6. Copy a List")
print("=" * 40)
def copy_list(lst):
    new_list = []
    for item in lst:
        new_list.append(item)
    return new_list

copied = copy_list(nums)
print(f"Original: {nums}")
print(f"Copied:   {copied}")

# Q7. Insert Element at Position
print("\n" + "=" * 40)
print("Q7. Insert Element at Position")
print("=" * 40)
def insert_at(lst, index, val):
    copy = lst[:]
    copy.insert(index, val)
    return copy

print(f"After inserting 99 at index 3: {insert_at(nums, 3, 99)}")

# Q8. Find Minimum and Maximum
print("\n" + "=" * 40)
print("Q8. Find Min and Max")
print("=" * 40)
def find_min_max(lst):
    mn = lst[0]
    mx = lst[0]
    for n in lst:
        if n < mn:
            mn = n
        if n > mx:
            mx = n
    return mn, mx

mn, mx = find_min_max(nums)
print(f"Min: {mn}, Max: {mx}")

# Q9. Reverse a List
print("\n" + "=" * 40)
print("Q9. Reverse a List")
print("=" * 40)
def reverse_list(lst):
    return lst[::-1]

print(f"Original: {nums}")
print(f"Reversed: {reverse_list(nums)}")

# Q10. Find Duplicate Elements
print("\n" + "=" * 40)
print("Q10. Find Duplicate Elements")
print("=" * 40)
def find_duplicates(lst):
    seen = []
    duplicates = []
    for n in lst:
        if n in seen and n not in duplicates:
            duplicates.append(n)
        seen.append(n)
    return duplicates

print(f"Duplicates: {find_duplicates(nums)}")

# Q11. Count Even and Odd
print("\n" + "=" * 40)
print("Q11. Count Even and Odd")
print("=" * 40)
def count_even_odd(lst):
    evens = sum(1 for n in lst if n % 2 == 0)
    odds = len(lst) - evens
    return evens, odds

e, o = count_even_odd(nums)
print(f"Even count: {e}, Odd count: {o}")

# Q12. Common Elements Between Two Lists
print("\n" + "=" * 40)
print("Q12. Common Elements")
print("=" * 40)
list1 = [1, 2, 3, 4, 5]
list2 = [3, 4, 5, 6, 7]
common = [x for x in list1 if x in list2]
print(f"List1: {list1}")
print(f"List2: {list2}")
print(f"Common elements: {common}")

# Q13. Remove Duplicates
print("\n" + "=" * 40)
print("Q13. Remove Duplicates")
print("=" * 40)
def remove_duplicates(lst):
    result = []
    for n in lst:
        if n not in result:
            result.append(n)
    return result

print(f"Original: {nums}")
print(f"No duplicates: {remove_duplicates(nums)}")

# Q14. Second Largest Element
print("\n" + "=" * 40)
print("Q14. Second Largest Element")
print("=" * 40)
def second_largest(lst):
    unique = list(set(lst))
    unique.sort()
    return unique[-2]

print(f"Second largest: {second_largest(nums)}")

# Q15. Difference Between Max and Min
print("\n" + "=" * 40)
print("Q15. Difference Between Max and Min")
print("=" * 40)
def diff_max_min(lst):
    return max(lst) - min(lst)

print(f"Difference (max - min): {diff_max_min(nums)}")

# Q16. Check for Specific Elements
print("\n" + "=" * 40)
print("Q16. Check for 12 and 23 in list")
print("=" * 40)
def check_12_and_23(lst):
    return 12 in lst and 23 in lst

print(f"List contains both 12 and 23: {check_12_and_23(nums)}")

# Q17. Unique Elements Only
print("\n" + "=" * 40)
print("Q17. Unique Elements Only")
print("=" * 40)
lst_with_dups = [1, 2, 2, 3, 4, 4, 5]
unique = list(dict.fromkeys(lst_with_dups))
print(f"Original: {lst_with_dups}")
print(f"Unique: {unique}")

# Q18. Frequency Count
print("\n" + "=" * 40)
print("Q18. Frequency Count")
print("=" * 40)
def freq_count(lst):
    freq = {}
    for n in lst:
        freq[n] = freq.get(n, 0) + 1
    return freq

print(f"Frequency: {freq_count(nums)}")

# Q19. List Sorting Without Built-in Functions (Bubble Sort)
print("\n" + "=" * 40)
print("Q19. Sorting Without Built-in Functions")
print("=" * 40)
def bubble_sort(lst):
    arr = lst[:]
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr

print(f"Original: {nums}")
print(f"Sorted:   {bubble_sort(nums)}")

# Q20. Merge Two Lists Without Duplicates
print("\n" + "=" * 40)
print("Q20. Merge Two Lists Without Duplicates")
print("=" * 40)
l1 = [1, 2, 3, 4]
l2 = [3, 4, 5, 6]
merged = list(dict.fromkeys(l1 + l2))
print(f"List1: {l1}")
print(f"List2: {l2}")
print(f"Merged (no duplicates): {merged}")
