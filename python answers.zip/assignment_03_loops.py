# Assignment-3: Loops & Control Flow in Python

# Q1. Print a Message Multiple Times
print("=" * 40)
print("Q1. Print Message 10 Times")
print("=" * 40)
for i in range(10):
    print("Bright IT Career")

# Q2. Print Numbers Using While Loop
print("\n" + "=" * 40)
print("Q2. Print 1 to 20 using While Loop")
print("=" * 40)
i = 1
while i <= 20:
    print(i, end=" ")
    i += 1
print()

# Q3. Equal and Not Equal Check
print("\n" + "=" * 40)
print("Q3. Equal and Not Equal Check")
print("=" * 40)
a, b = 5, 5
print(f"{a} == {b} : {a == b}")
print(f"{a} != {b} : {a != b}")

a, b = 5, 10
print(f"{a} == {b} : {a == b}")
print(f"{a} != {b} : {a != b}")

# Q4. Odd and Even Numbers
print("\n" + "=" * 40)
print("Q4. Odd and Even from 1 to 50")
print("=" * 40)
even_nums = []
odd_nums = []
for num in range(1, 51):
    if num % 2 == 0:
        even_nums.append(num)
    else:
        odd_nums.append(num)
print("Even:", even_nums)
print("Odd: ", odd_nums)

# Q5. Largest Among Three Numbers
print("\n" + "=" * 40)
print("Q5. Largest Among Three Numbers")
print("=" * 40)
a, b, c = 15, 42, 27
if a >= b and a >= c:
    print(f"Largest among {a}, {b}, {c} is: {a}")
elif b >= a and b >= c:
    print(f"Largest among {a}, {b}, {c} is: {b}")
else:
    print(f"Largest among {a}, {b}, {c} is: {c}")

# Q6. Even Numbers in a Range (While Loop)
print("\n" + "=" * 40)
print("Q6. Even Numbers between 10 and 20")
print("=" * 40)
n = 10
while n <= 20:
    if n % 2 == 0:
        print(n, end=" ")
    n += 1
print()

# Q7. Armstrong Number
print("\n" + "=" * 40)
print("Q7. Armstrong Number Check")
print("=" * 40)
def is_armstrong(num):
    digits = str(num)
    power = len(digits)
    total = sum(int(d) ** power for d in digits)
    return total == num

for num in [153, 370, 123, 9474]:
    if is_armstrong(num):
        print(f"{num} is an Armstrong number")
    else:
        print(f"{num} is NOT an Armstrong number")

# Q8. Prime Number Check
print("\n" + "=" * 40)
print("Q8. Prime Number Check")
print("=" * 40)
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

for num in [2, 7, 10, 13, 25]:
    print(f"{num} is {'a Prime' if is_prime(num) else 'NOT a Prime'} number")

# Q9. Palindrome Check
print("\n" + "=" * 40)
print("Q9. Palindrome Check")
print("=" * 40)
def is_palindrome(num):
    return str(num) == str(num)[::-1]

for num in [121, 1221, 123, 12321]:
    print(f"{num} is {'a Palindrome' if is_palindrome(num) else 'NOT a Palindrome'}")

# Q10. Even or Odd
print("\n" + "=" * 40)
print("Q10. Even or Odd")
print("=" * 40)
for n in [4, 7, 12, 19]:
    print(f"{n} is {'Even' if n % 2 == 0 else 'Odd'}")

# Q11. Gender Identification
print("\n" + "=" * 40)
print("Q11. Gender Identification")
print("=" * 40)
def identify_gender(code):
    if code == 'M':
        print("Male")
    elif code == 'F':
        print("Female")
    else:
        print("Invalid Input")

identify_gender('M')
identify_gender('F')
identify_gender('X')

# Q12. Multiplication Table
print("\n" + "=" * 40)
print("Q12. Multiplication Table")
print("=" * 40)
n = 5
print(f"Multiplication table of {n}:")
for i in range(1, 11):
    print(f"{n} x {i} = {n * i}")

# Q13. Count Digits
print("\n" + "=" * 40)
print("Q13. Count Digits in a Number")
print("=" * 40)
def count_digits(num):
    count = 0
    num = abs(num)
    while num > 0:
        num //= 10
        count += 1
    return count

for n in [12345, 987, 7]:
    print(f"Digits in {n}: {count_digits(n)}")
