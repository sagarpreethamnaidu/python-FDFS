# Assignment-5: Class Variables in Python

# Q1. Define and Access via Class
print("=" * 40)
print("Q1. Define and Access via Class")
print("=" * 40)
class School:
    name = "JALA Academy"

print(f"School name: {School.name}")

# Q2. Access via Object (Instance)
print("\n" + "=" * 40)
print("Q2. Access via Object")
print("=" * 40)
s1 = School()
print(f"School name via object: {s1.name}")

# Q3. Modify Class Variable via Instance
print("\n" + "=" * 40)
print("Q3. Modify Class Variable via Instance")
print("=" * 40)
s1.name = "Modified by Instance"
print(f"Value via instance: {s1.name}")
print(f"Value via class (unchanged): {School.name}")

# Q4. Modify Class Variable via Class
print("\n" + "=" * 40)
print("Q4. Modify Class Variable via Class")
print("=" * 40)
School.name = "Updated JALA Academy"
s2 = School()
s3 = School()
print(f"Via class: {School.name}")
print(f"Via s2: {s2.name}")
print(f"Via s3: {s3.name}")

# Q5. Class Variable vs Instance Variable
print("\n" + "=" * 40)
print("Q5. Class Variable vs Instance Variable")
print("=" * 40)
class Student:
    college = "JALA College"  # class variable

    def __init__(self, name):
        self.name = name  # instance variable

st1 = Student("Sagar")
st2 = Student("Ravi")
print(f"st1 name: {st1.name}, college: {st1.college}")
print(f"st2 name: {st2.name}, college: {st2.college}")

Student.college = "New College"
print(f"After class change - st1 college: {st1.college}")
print(f"After class change - st2 college: {st2.college}")

# Q6. Shared Counter Program
print("\n" + "=" * 40)
print("Q6. Shared Counter Program")
print("=" * 40)
class Counter:
    count = 0

    def __init__(self, name):
        self.name = name
        Counter.count += 1

c1 = Counter("Alice")
c2 = Counter("Bob")
c3 = Counter("Charlie")
print(f"Total students created: {Counter.count}")

# Q7. Configuration Setting Example
print("\n" + "=" * 40)
print("Q7. Configuration Setting Example")
print("=" * 40)
class Config:
    course_name = "Python Basics"

obj1 = Config()
obj2 = Config()
print(f"Default course: {Config.course_name}")

Config.course_name = "Advanced Python"
print(f"Updated via class - obj1: {obj1.course_name}")
print(f"Updated via class - obj2: {obj2.course_name}")
