# Assignment-13: Functions & Flexible Arguments in Python

# Q1. Function with Parameters
print("=" * 40)
print("Q1. Function with Parameters")
print("=" * 40)
def add(a, b):
    return a + b

print(f"Sum of 5 and 3: {add(5, 3)}")

# Q2. Default Parameters
print("\n" + "=" * 40)
print("Q2. Default Parameters")
print("=" * 40)
def greet(name, message="Hello"):
    print(f"{message}, {name}!")

greet("Sagar")
greet("Ravi", "Good Morning")

# Q3. Keyword Arguments
print("\n" + "=" * 40)
print("Q3. Keyword Arguments")
print("=" * 40)
def student_info(name, age, city):
    print(f"Name: {name}, Age: {age}, City: {city}")

student_info(name="Sagar", age=21, city="Hyderabad")
student_info(city="Vizag", name="Ravi", age=23)

# Q4. Using *args
print("\n" + "=" * 40)
print("Q4. Using *args")
print("=" * 40)
def sum_all(*args):
    total = 0
    for n in args:
        total += n
    return total

print(f"Sum(1,2,3): {sum_all(1, 2, 3)}")
print(f"Sum(1,2,3,4,5): {sum_all(1, 2, 3, 4, 5)}")

# Q5. Using **kwargs
print("\n" + "=" * 40)
print("Q5. Using **kwargs")
print("=" * 40)
def print_details(**kwargs):
    for key, value in kwargs.items():
        print(f"  {key}: {value}")

print_details(name="Sagar", age=21, course="Python", city="Hyderabad")

# Q6. Flexible Function
print("\n" + "=" * 40)
print("Q6. Flexible Function (number or string)")
print("=" * 40)
def flexible(value):
    if isinstance(value, int) or isinstance(value, float):
        print(f"Square of {value} = {value ** 2}")
    elif isinstance(value, str):
        print(f"Uppercase: {value.upper()}")
    else:
        print("Unsupported type")

flexible(7)
flexible("python")

# Q7. Advanced Function
print("\n" + "=" * 40)
print("Q7. Advanced Function (default + *args + **kwargs)")
print("=" * 40)
def total_price(base_price=100, *items, **discounts):
    total = base_price
    print(f"Base price: {base_price}")
    for item in items:
        total += item
        print(f"  Added item: {item}")
    for key, val in discounts.items():
        total -= val
        print(f"  Discount ({key}): -{val}")
    print(f"Final total: {total}")

total_price(200, 50, 30, seasonal=20, coupon=10)

# Q8. Lambda Functions
print("\n" + "=" * 40)
print("Q8. Lambda Functions")
print("=" * 40)
add_lambda = lambda a, b: a + b
square_lambda = lambda x: x ** 2

print(f"Lambda add(4, 5): {add_lambda(4, 5)}")
print(f"Lambda square(6): {square_lambda(6)}")

# Q9. map() Function
print("\n" + "=" * 40)
print("Q9. map() Function")
print("=" * 40)
nums = [1, 2, 3, 4, 5]
squared = list(map(lambda x: x ** 2, nums))
print(f"Original: {nums}")
print(f"Squared via map(): {squared}")

# Q10. filter() Function
print("\n" + "=" * 40)
print("Q10. filter() Function")
print("=" * 40)
nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
evens = list(filter(lambda x: x % 2 == 0, nums))
print(f"Original: {nums}")
print(f"Even numbers via filter(): {evens}")
