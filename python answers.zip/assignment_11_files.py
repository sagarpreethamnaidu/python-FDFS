# Assignment-11: File Handling in Python

import os

# Helper: create a sample file
sample_file = "/tmp/sample.txt"
with open(sample_file, "w") as f:
    f.write("Hello, Python!\nThis is line 2.\nThis is line 3.\nFile handling is fun.")

# Q1. Read a Text File
print("=" * 40)
print("Q1. Read a Text File")
print("=" * 40)
with open(sample_file, "r") as f:
    content = f.read()
print(content)

# Q2. Write to a Text File
print("\n" + "=" * 40)
print("Q2. Write and Append to a Text File")
print("=" * 40)
write_file = "/tmp/output.txt"
# Write mode
with open(write_file, "w") as f:
    f.write("First line written by Python\n")
    f.write("Second line written by Python\n")
print("Written to file (mode 'w')")

# Append mode
with open(write_file, "a") as f:
    f.write("Third line appended by Python\n")
print("Appended to file (mode 'a')")

# Verify
with open(write_file, "r") as f:
    print(f.read())

# Q3. Read File Using File Object
print("\n" + "=" * 40)
print("Q3. read() vs readline() vs readlines()")
print("=" * 40)
with open(sample_file, "r") as f:
    data = f.read()
print(f"read() -> {repr(data[:30])}...")

with open(sample_file, "r") as f:
    line1 = f.readline()
print(f"readline() -> {repr(line1)}")

with open(sample_file, "r") as f:
    lines = f.readlines()
print(f"readlines() -> {lines}")

# Q4. Random Access File Reading (seek)
print("\n" + "=" * 40)
print("Q4. Random Access Using seek()")
print("=" * 40)
with open(sample_file, "r") as f:
    f.seek(7)  # move cursor to position 7
    data = f.read(6)
    print(f"After seek(7), read(6) -> '{data}'")

    f.seek(0)  # back to beginning
    data = f.read(5)
    print(f"After seek(0), read(5) -> '{data}'")

    pos = f.tell()
    print(f"Current cursor position (tell()): {pos}")

# Cleanup
os.remove(write_file)
print("\n(Temporary files cleaned up)")
