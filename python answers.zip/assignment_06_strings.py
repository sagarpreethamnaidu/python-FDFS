# Assignment-6: Strings in Python

# Q1. Creating Strings in Different Ways
print("=" * 40)
print("Q1. Creating Strings")
print("=" * 40)
s1 = 'Hello with single quotes'
s2 = "Hello with double quotes"
s3 = """Hello with
triple quotes - spans
multiple lines"""
print(s1)
print(s2)
print(s3)

# Q2. String Concatenation
print("\n" + "=" * 40)
print("Q2. String Concatenation")
print("=" * 40)
first = "Hello"
second = " World"
result = first + second
print(f"Concatenated: {result}")

# Q3. Length of a String
print("\n" + "=" * 40)
print("Q3. Length of a String")
print("=" * 40)
text = "Python Programming"
print(f"String: '{text}'")
print(f"Length: {len(text)}")

# Q4. Extract Substring
print("\n" + "=" * 40)
print("Q4. Extract Substring (Slicing)")
print("=" * 40)
text = "Python Programming"
print(f"Original: {text}")
print(f"First 6 chars:  {text[:6]}")
print(f"Last 11 chars:  {text[7:]}")
print(f"Chars 0 to 5:   {text[0:6]}")
print(f"Every 2nd char: {text[::2]}")

# Q5. Search in String
print("\n" + "=" * 40)
print("Q5. Search in String")
print("=" * 40)
text = "Python is easy and Python is fun"
word = "Python"
print(f"find('{word}'): {text.find(word)}")
print(f"index('{word}'): {text.index(word)}")

# Not found case
missing = "Java"
pos = text.find(missing)
if pos == -1:
    print(f"'{missing}' not found using find()")
try:
    text.index(missing)
except ValueError:
    print(f"'{missing}' not found using index() - ValueError raised")

# Q6. Compare Strings
print("\n" + "=" * 40)
print("Q6. Compare Strings")
print("=" * 40)
a = "hello"
b = "hello"
c = "world"
print(f"'{a}' == '{b}' : {a == b}")
print(f"'{a}' != '{c}' : {a != c}")

# Q7. startswith() and endswith()
print("\n" + "=" * 40)
print("Q7. startswith() and endswith()")
print("=" * 40)
text = "Python Programming"
print(f"Starts with 'Python': {text.startswith('Python')}")
print(f"Starts with 'Java':   {text.startswith('Java')}")
print(f"Ends with 'ing':      {text.endswith('ing')}")
print(f"Ends with 'Python':   {text.endswith('Python')}")

# Q8. String Methods
print("\n" + "=" * 40)
print("Q8. String Methods")
print("=" * 40)
text = "  hello world  "
print(f"Original: '{text}'")
print(f"upper():  '{text.upper()}'")
print(f"lower():  '{text.lower()}'")
print(f"strip():  '{text.strip()}'")
print(f"replace('world','Python'): '{text.strip().replace('world','Python')}'")
print(f"split(): {text.strip().split()}")
